import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Subject, debounceTime, distinctUntilChanged, switchMap } from 'rxjs';
import { Market } from '../../models/market.model';
import { MarketService } from '../../services/market.service';
import { MarketCardComponent } from '../market-card/market-card.component';

@Component({
  selector: 'app-market-list',
  standalone: true,
  imports: [CommonModule, FormsModule, MarketCardComponent],
  templateUrl: './market-list.component.html',
  styleUrl: './market-list.component.css',
})
export class MarketListComponent implements OnInit {
  markets: Market[] = [];
  loading = true;
  error: string | null = null;
  searchTerm = '';

  private searchInput$ = new Subject<string>();

  constructor(private marketService: MarketService) {}

  ngOnInit(): void {
    this.loadTrending();

    this.searchInput$
      .pipe(
        debounceTime(300),
        distinctUntilChanged(),
        switchMap((term) => {
          this.loading = true;
          this.error = null;
          return term.trim()
            ? this.marketService.search(term.trim())
            : this.marketService.getTrending();
        })
      )
      .subscribe({
        next: (markets) => {
          this.markets = markets;
          this.loading = false;
        },
        error: () => {
          this.error = 'Could not reach the market data. Is the API running?';
          this.loading = false;
        },
      });
  }

  onSearchChange(term: string): void {
    this.searchTerm = term;
    this.searchInput$.next(term);
  }

  private loadTrending(): void {
    this.loading = true;
    this.error = null;
    this.marketService.getTrending().subscribe({
      next: (markets) => {
        this.markets = markets;
        this.loading = false;
      },
      error: () => {
        this.error = 'Could not reach the market data. Is the API running?';
        this.loading = false;
      },
    });
  }
}
